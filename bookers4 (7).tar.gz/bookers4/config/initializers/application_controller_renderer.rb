# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end
 Refile.secret_key = 'a903f4742b4be4786585fc7431dc4a1b39242987a251c9be2a1b3cf2515b08a1f1ab20ea483e2dcf44cab64b1d515218911ee93aa7b5916dabae3e0ccb6c673f'